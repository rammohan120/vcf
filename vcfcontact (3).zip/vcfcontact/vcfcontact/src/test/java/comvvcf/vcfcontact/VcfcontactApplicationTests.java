package comvvcf.vcfcontact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VcfcontactApplicationTests {

	@Test
	void contextLoads() {
	}

}
