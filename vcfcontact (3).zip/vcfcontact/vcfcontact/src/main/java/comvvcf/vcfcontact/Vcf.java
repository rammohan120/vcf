package comvvcf.vcfcontact;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Vcf {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String address;
    private String number;

    private String Email;

    @Lob
    private byte[] image;


    private String addresslink;

    private String jobTitle;

    private String facebook;


//    public String getImagePath(String s) {
//        s="static/rammohan.png";
//        return s;
//    }


}
