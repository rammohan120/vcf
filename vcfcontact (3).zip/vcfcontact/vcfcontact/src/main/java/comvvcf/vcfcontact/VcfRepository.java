package comvvcf.vcfcontact;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VcfRepository extends JpaRepository<Vcf, Long> {

    Vcf findByName(String name);

}
