package comvvcf.vcfcontact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.codec.binary.Base64;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@RestController
public class VcfController {
    @Autowired
    VcfService service;

    @GetMapping("/contacts.vcf/{name}")
    public void downloadVCF(HttpServletResponse response, @PathVariable String name) throws IOException {
        response.setContentType("text/vcard");
        response.setHeader("Content-Disposition", "attachment; filename=\"contacts.vcf\"");


        Vcf contacts = service.findByName(name);

        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(response.getOutputStream()));


            writer.write("BEGIN:VCARD\n");
            writer.write("VERSION:3.0\n");
            writer.write("N:" + contacts.getName() + "\n");
            writer.write("ADR;TYPE=Home;City:" + contacts.getAddress() + "\n");
            writer.write("TEL;TYPE=Work:" +contacts.getNumber()+"\n");
            writer.write("EMAIL;TYPE=Work:"+contacts.getEmail()+"\n");
            writer.write("TITLE: "+contacts.getJobTitle()+"\n");
            writer.write("URL: " + contacts.getAddresslink() + "\n");
            writer.write("URL: "+contacts.getFacebook()+"\n");


            byte[] imageData = contacts.getImage();

             // Encode the image data as a Base64 string
            String base64Image = Base64.encodeBase64String(imageData);

            writer.write("PHOTO;TYPE=JPG;ENCODING=BASE64: " + base64Image + "\n");



            writer.write("END:VCARD\n");
            writer.flush();
            writer.close();
        }



    }




