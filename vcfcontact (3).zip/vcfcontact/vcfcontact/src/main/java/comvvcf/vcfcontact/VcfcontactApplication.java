package comvvcf.vcfcontact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class VcfcontactApplication {


	public static void main(String[] args) {
		SpringApplication.run(VcfcontactApplication.class, args);

	}

}
