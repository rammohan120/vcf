package comvvcf.vcfcontact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

@Component
public class Utill  implements ApplicationRunner {
    @Autowired
    VcfRepository repo;
    @Autowired
    private ResourceLoader resourceLoader;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        repo.deleteAll();

        Vcf s1 = new Vcf();
        s1.setName("P.Ram Mohan");
        s1.setAddress("Madhapur,Hyderabad");
        s1.setNumber("7995780215");
        s1.setEmail("rammohanp888@gmail.com");
        s1.setAddresslink("https://goo.gl/maps/PmS8iQK5Q9gGDEy1A");
        s1.setJobTitle("Java Developer");
        s1.setFacebook("https://www.facebook.com/rammohansvu");


        String imagePath = "static/rammohan.png";
        ClassPathResource resource = new ClassPathResource(imagePath);

        try (InputStream inputStream = resource.getInputStream()) {
            byte[] imageData = FileCopyUtils.copyToByteArray(inputStream);

            s1.setImage(imageData);
        }



        List<Vcf> list = Arrays.asList(s1);
        repo.saveAll(list);

    }
}
