package comvvcf.vcfcontact;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
    public class VcfService {

        @Autowired
        private VcfRepository vcfRepository;

//        public Vcf getVcf() {
//            return vcfRepository.findFirstByOrderByIdDesc();
//        }

    public Vcf findByName(String name) {
            return vcfRepository.findByName(name);
    }
}


